create table actor(
actor_ID number(22),
constraint actor_pk primary key(actor_ID),
first_name varchar(45),
last_name varchar(45),
Last_update timestamp);

select * from actor;

create table film_actor(
actor_ID number(22),
constraint film_actor_actor_fk FOREIGN KEY (actor_ID) references film_actor,
film_ID number(22),
constraint film_actor_pk primary key (film_ID),
Last_update timestamp);
select * from film_actor;


create table language (
language_ID number(22),
constraint language_uk primary key (language_ID),
name_l char(20),
Last_update timestamp);
select * from language;

create table film(
film_ID number(22),
constraint film_pk primary key (film_ID),
title varchar2(255),
descript CLOB,
release_year varchar2(4),
constraint release_year_uk unique(release_year),
language_ID number(22),
constraint film_languange_fk FOREIGN KEY (language_ID) references film,
original_lang_ID number(22),
constraint original_lang_ID_uk unique (original_lang_ID),
rental_duration number(22),
rental_rate number(4,2),
leng number(22),
constraint leng_uk unique (leng),
replacement_cost number(5,2),
rating varchar2(10),
constraint rating_uk unique (rating),
special_features varchar2(100),
constraint special_features_uk unique (special_features),
Last_update timestamp);
select * from film;



create table film_category(
film_ID number(22),
constraint film_category_film_fk FOREIGN KEY (film_ID) references film_category,
category_ID number(22),
constraint film_category_pk primary key (category_ID),
Last_update timestamp);
select * from film_category; 

create table category(
category_ID number(22),
constraint category_pk primary key (category_ID),
nam varchar(25),
Last_update timestamp);
select * from category;


create table staff(
staff_ID number(22),
constraint staff_pk primary key(staff_ID),
first_name varchar2(45),
last_name varchar2(45),
address_ID number(22),
constraint staff_address_fk FOREIGN KEY (address_ID) references staff,
picture BLOB,
email varchar2(50),
constraint e_mail_uk unique(email),
store_ID number(22),
constraint staff_store_fk FOREIGN KEY (store_ID) references staff,
active number(22),
username varchar2(16),
login varchar(40),
constraint log_in_uk unique (login),
Last_update timestamp);
select * from staff;


create table payment(
payment_ID number(22),
constraint payment_pk primary key (payment_ID),
customer_ID number(22),
constraint payment_customer_fk FOREIGN KEY (customer_ID) references payment,
staff_ID number(22),
constraint payment_staff_fk FOREIGN KEY (staff_ID) references payment,
rental_ID number(22),
constraint rental_ID_uk unique (rental_ID),
constraint payment_rental_fk FOREIGN KEY (rental_ID) references payment,
amount number(5,2),
payment_date timestamp,
last_update timestamp);
drop table payment;

select * from payment;


create table rental(
rental_ID number(22),
constraint rental_pk primary key (rental_ID),
rental_date timestamp,
inventory_ID number(22),
constraint rental_inventory_fk FOREIGN KEY (inventory_ID) references rental,
customer_ID number(22),
constraint rental_customer_fk FOREIGN KEY (customer_ID) references rental,
return_date timestamp,
constraint rental_date_uk unique (return_date),
staff_ID number(22),
constraint rental_payment_fk FOREIGN KEY (staff_ID) references rental,
last_update timestamp);
select * from rental;


create table inventory(
inventory_ID number(22),
constraint inventory_pk primary key (inventory_ID),
film_ID number(22),
constraint inventory_film_fk FOREIGN KEY (film_ID) references inventory,
store_ID number(22),
constraint inventory_store_fk FOREIGN KEY (store_ID) references inventory, 
last_update timestamp);
select * from inventory;


create table store(
store_ID number(22),
constraint store_pk primary key (store_ID),
manager_staff_ID number(22),
address_ID number(22),
constraint store_address_fk FOREIGN KEY (address_ID) references store,
last_update timestamp);
select * from store;

create table customer(
customer_ID number(22),
constraint customer_pk primary key(customer_ID),
store_ID number(22),
constraint customer_store_fk FOREIGN KEY (store_ID) references customer,
first_name varchar(45),
last_name varchar2(45),
email varchar(50),
constraint email_uk unique (email),
address_ID number(22),
constraint customer_address_fk FOREIGN KEY(address_ID) references customer,
active char(1),
create_date date,
last_update timestamp);

select * from customer;

create table address(
address_ID number(22),
constraint address_pk primary key(address_ID),
address varchar2(50),
address2 varchar2(50),
constraint address2_uk unique(address2),
district varchar2(20),
city_ID number(22),
constraint address_city_fk FOREIGN KEY (city_ID) references address,
postal_code varchar2(10),
constraint postal_code unique(postal_code),
phone varchar2(20),
Last_update timestamp);
select * from address;

create table city(
city_ID number(22),
constraint city_pk primary key(city_ID),
city varchar2(50),
country_ID number(22),
constraint city_country_fk FOREIGN KEY (country_ID) references city,
Last_update timestamp);
select * from city;

create table country (
country_ID number(22),
constraint country_pk primary key(country_ID),
country varchar2(50),
Last_update timestamp,
constraint last_update_uk unique(Last_update));
select * from country;






